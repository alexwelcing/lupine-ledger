A Cloudflare research team for materials science
Lupine Science — 26 October 2026

Publication package for the existing Lupine Library:
https://library.lupine.science/#/read/cloudflare-research-team
https://library.lupine.science/#/read/cloudflare-research-team-methods

This is an internally reviewed working paper, not an externally peer-reviewed
journal publication. Read 2026-10-26-cloudflare-research-team.md first. The
companion methods article provides measurement definitions, individual report
sizes and source identities.

The five CSV files contain selected operational metadata. Raw prompts, reasoning,
credentials and private source contents are excluded. public-data-manifest.json
records each CSV's byte count and SHA-256 hash.

The desktop recurring automation was deleted and the hosted research loop was
paused with its next alarm cleared, as verified on 26 October 2026. Historical
receipts were retained. No further scheduled check-ins are intended.
